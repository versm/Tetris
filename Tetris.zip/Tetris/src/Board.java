import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Board extends JPanel implements KeyListener {

    JPanel [][] board;
    int NUMBER_OF_COLUMNS= 10;
    int NUMBER_OF_ROWS= 20;
    int boardCellSize = Game.height/20;


    public Board(){
        this.setPreferredSize(new Dimension(Game.width,Game.height));
        this.setBackground(Color.BLACK);
        this.setLayout(null);

        board = new JPanel[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];

        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                JPanel jPanel = new JPanel();
                board[i][j] = jPanel;
                jPanel.setBounds(j * boardCellSize, i * boardCellSize, boardCellSize, boardCellSize);
                if ((i % 2 == 0 && j % 2 ==0) || (i % 2 == 1 && j % 2 ==1))
                    jPanel.setBackground(Color.BLACK);
                else
                    jPanel.setBackground(Color.RED);

                this.add(jPanel);
            }
        }

        this.addKeyListener(this);
        this.requestFocus();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);


    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {


        System.out.println("lalaal");;
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
