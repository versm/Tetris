import javax.swing.*;
import java.awt.*;

public class Menu extends JPanel {


    public Menu() {
        setPreferredSize(new Dimension(Game.width/2,Game.height));
        setBackground(Color.GRAY);
        setBorder(BorderFactory.createSoftBevelBorder(5,Color.BLACK,Color.GRAY));
    }
}
