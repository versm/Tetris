public class Shape {

    int size = Game.height/20;


    Shape(){

    }
}
